
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <asm/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include <err.h>
#include <signal.h>

#include <dirent.h>

#include <getopt.h>
#include "lirc_client.h"

#include <linux/input.h>
#include <linux/uinput.h>

#define PROGNAME "rcircat"
#define VERSION "0.2.1"

#define MAX_KEY_COMBINATION 5

#define UNKNOW_MODULE 0
#define RCMOD_MODULE 1
#define EVDEV_MODULE 2
#define UINPUT_MODULE 3

#define test_bit(bit, array)    (array[bit/8] & (1<<(bit%8)))

unsigned char debug=0;
static int fd=-1;       /* the file descriptor for the device */
static unsigned char typemodule=UNKNOW_MODULE;
static struct lirc_config *config;

void handlesign(int);

static int uinput_open(char * device)
{
    struct uinput_user_dev dev;
    int fd, aux;

    if ( (fd = open(device, O_RDWR)) < 0 )
        return fd;

    memset(&dev, 0, sizeof(dev));

    strncpy(dev.name,PROGNAME" input", UINPUT_MAX_NAME_SIZE);
    dev.id.bustype = BUS_I2C;
    dev.id.vendor  = 0x0000;
    dev.id.product = 0x0000;
    dev.id.version = 0x0001;

    if (write(fd, &dev, sizeof(dev)) < 0) {
            fprintf(stderr, "Can't write device information: %s (%d)\n",
                                                    strerror(errno), errno);
            close(fd);
            return -1;
    }

    /* mouse pointer emulation */
    /*ioctl(fd, UI_SET_EVBIT, EV_REL);

    for (aux = REL_X; aux <= REL_MISC; aux++)
        ioctl(fd, UI_SET_RELBIT, aux);*/

    /* keyboard and mouse button emulation */
    ioctl(fd, UI_SET_EVBIT, EV_KEY);
    ioctl(fd, UI_SET_EVBIT, EV_REP);

    for (aux = KEY_ESC ; aux < KEY_MAX; aux++)
        ioctl(fd, UI_SET_KEYBIT, aux);

    /* led control emulation */
    //ioctl(fd, UI_SET_EVBIT, EV_LED);
    //for (aux = LED_NUML; aux <= LED_MISC; aux++)
    //	ioctl(fd, UI_SET_LEDBIT, aux);
    
    ioctl(fd, UI_DEV_CREATE);

    return fd;
}

static unsigned char send_syn_event(int fd)
{
    struct input_event ev; /* the event */

    memset(&ev, 0, sizeof(ev));

    ev.type = EV_SYN;
    if (debug)
        printf("Sync fd %d\n",fd);
    if ( write(fd, &ev, sizeof(struct input_event)) != sizeof(struct input_event) ) {
        warn(" writing in input device incomplete");
        return 0;
    }

    return 1;
}

/*
static unsigned char send_kbd_event(int fd, uint16_t code)
{
    struct input_event ev; // the event 
    unsigned char ret=1;

    memset(&ev, 0, sizeof(ev));

    ev.type = EV_KEY;
    ev.code= code ;
    ev.value = 1;
    if ( write(fd, &ev, sizeof(struct input_event)) != sizeof(struct input_event) ) {
        ret=0;
        warn(" writing in input device incomplete");
    }
    ev.value = 0;
    if ( write(fd, &ev, sizeof(struct input_event)) != sizeof(struct input_event) ) {
        ret=0;
        warn(" writing in input device incomplete");
    }
    ev.type = EV_SYN;
    ev.code= 0;
    ev.value = 0;
    if ( write(fd, &ev, sizeof(struct input_event)) != sizeof(struct input_event) ) {
        ret=0;
        warn(" writing in input device incomplete");
    }

    return ret;
}
*/


/*! Recursive function to send keys combination in a event module.
 *
 * \return 0 if a warning occurs, 1 else.
 */
static unsigned char rsend_nkbd_event(int fd, uint16_t * code,unsigned char n)
{
        struct input_event ev; /* the event */
	unsigned char ret=1;


    if ( n == 0 )
        return 1;
    else {
	memset(&ev, 0, sizeof(ev));

        ev.type = EV_KEY;
        ev.code= *code ;
        ev.value = 1;
        if (debug)
            printf("Press %04x (%d) ",*code,*code);
        if ( write(fd, &ev, sizeof(struct input_event)) != sizeof(struct input_event) ) {
            ret=0;
            warn(" writing in input device incomplete");
        }

        if ( rsend_nkbd_event(fd,code+1,n-1) == 0 )
            ret =0 ;
        
        ev.value = 0;
        if (debug)
            printf("Release %04x (%d) ",*code,*code);
        if ( write(fd, &ev, sizeof(struct input_event)) != sizeof(struct input_event) ) {
            ret=0;
            warn(" writing in input device incomplete");
        }
    }
    return ret;
}


static unsigned int send_kbdcombination_str(int fd, char * str)
{
    unsigned int i=0;
    char * pplus;
    uint16_t kcodes[MAX_KEY_COMBINATION];

    while ( ( pplus=strchr(str,'+') ) && (i < MAX_KEY_COMBINATION-2) ) {
        *pplus='\0';
        kcodes[i++]=(uint16_t)strtoul(str,NULL,0);
        *pplus='+';
        str=++pplus;
    }
    /* strtoul stop after first invalid char, so if the input string contain more key than MAX_KEY_COMBINATION, they are ignored */
    kcodes[i++]=(uint16_t)strtoul(str,NULL,0);
    rsend_nkbd_event(fd,kcodes,i);
    return i;
}

int main (int argc, char *argv[]) {

    char *code, *c;
    int ret=0;

    unsigned char daemonize=1;
    char * lircprogname=NULL, * devicename;
    char * configfile="/etc/lircrc";

    int opt;
    static struct option long_options[] =
    {
            {"help",no_argument,NULL,'h'},
            {"version",no_argument,NULL,'v'},
            {"foreground",no_argument,NULL,'f'},
            {"debug",no_argument,NULL,'d'},
            {"name",required_argument,NULL,'n'},
            {"config",required_argument,NULL,'c'},
            {"type",required_argument,NULL,'t'},
            {0, 0, 0, 0}
    };
    opterr=0;

    while( ( opt = getopt_long(argc,argv,"hvfdn:c:t:",long_options,NULL) ) != -1 ) {
        switch (opt) {
        case 'h':
            printf(PROGNAME" v."VERSION" - write lirc event into an input device\n");
            printf("Usage: %s [options] event-device - probably /dev/input/uinput\n",argv[0]);
            printf("\t -h --help\t\tdisplay usage summary\n");
            printf("\t -v --version\t\tdisplay version\n");
//            printf("\t -f --foreground\t\tdon't run in background\n");
            printf("\t -d --debug\t\twrite debug messages\n");
            printf("\t -n --name\t\tuse this program name in config file (default event-device name)\n");
            printf("\t -c --config\t\tlircrc config file (default /etc/lircrc)\n");
            printf("\t -t --type\t\t force input type (rcmod, evdev or uinput), default is name detected :\n");
            printf("If the name of the device is \"rc\", %s assume it is a ST-API rc device, and will wait that rcmod is loaded\n",argv[0]);
            printf("If the name of the device is \"uinput\", %s will create and use a user input device\n",argv[0]);
            return(0);
        case 'v':
            printf(PROGNAME" v."VERSION"\n");
            return(0);
        case 'f':
            daemonize=0;
            break;
        case 'd':
            debug=1;
            break;
        case 'n':
            lircprogname=optarg;
            break;
        case 'c':
            configfile=optarg;
            break;
        case 't':
            if ( ! strcasecmp("uinput",optarg) )
                typemodule=UINPUT_MODULE;
            else if ( ! strcasecmp("evdev",optarg) )
                typemodule=EVDEV_MODULE;
            else if ( ! strcasecmp("rcmod",optarg) )
                typemodule=RCMOD_MODULE;
            else
                warnx("type %s is not a recognized module name -> option ignored.", optarg);
            break;
        case '?':
            fprintf(stderr,"unrecognized option: -%c\n", optopt);
            return(-1);
        }
    }
    if (optind >= argc ) {
        fprintf(stderr,"Usage: %s [options] input device - probably /dev/input/uinput\n",argv[0]);
        return(-1);
    }

    /* check input parameters */
    if ( (devicename = strrchr(argv[optind],'/') ) == NULL )
        devicename = argv[optind];
    else devicename++;

    if ( lircprogname == NULL )
        lircprogname=devicename;

    if ( typemodule == UNKNOW_MODULE ) {
        if ( ! strcmp(devicename,"rc") )
            typemodule=RCMOD_MODULE;
        else if ( ! strcasecmp(devicename,"uinput") )
            typemodule=UINPUT_MODULE;
        else
            typemodule=EVDEV_MODULE;
    }

    /* start lirc connexion */
    if (lirc_init(lircprogname, 1) == -1) exit(2);

    if (lirc_readconfig(configfile, &config, NULL) != 0) {
        lirc_deinit();
        exit(2);
    }

    signal(SIGINT,handlesign);
    signal(SIGQUIT,handlesign);
    signal(SIGTERM,handlesign);

    if ( typemodule == RCMOD_MODULE ) {
        DIR * dd;
        do {
            while (  ( dd=opendir("/sys/module/rcmod") ) == NULL ) {
            //if ( ( dd=opendir("/sys/module/rcmod") ) == NULL ) {
                if ( errno != ENOENT )
                    err(1,"/sys/module/rcmod : ");
                else
                    break;
                sleep(2);
            }

            closedir(dd);

            if ((fd = open(argv[optind], O_WRONLY)) < 0) 
                err(1,"rc open");

            while (lirc_nextcode(&code) == 0) {
                if (code == NULL) continue;
                while ((ret = lirc_code2char(config, code, &c)) == 0 &&
                      c != NULL) {
                    if (debug)
                        printf("%s -> \"%s\" written in %s\n",code,c,argv[optind]);
                    if ( dprintf(fd,"%s\n", c) < 0 )
                        warn(" writing in %s",argv[optind]);
                }
                free(code);
                if (ret == -1) break;
            }

            if ( ! close(fd) ) {
                warn("rc close");
                break;
            }
        } while ( ! sleep(5) ) ;
    }
    else if ( typemodule == UINPUT_MODULE ) {
        /* we are using uinput (best choice !) */

        if ((fd = uinput_open(argv[optind])) < 0) 
        err(1," uinput_open");

        while (lirc_nextcode(&code) == 0) {
            if (code == NULL) continue;
            while ((ret = lirc_code2char(config, code, &c)) == 0 &&
                  c != NULL) {
                char * pspace;
                
                if (debug) 
                    printf("%s -> %s -> ",code,c);
                while ( ( pspace=strchr(c,' ') ) ) {
                    *pspace='\0';
                    send_kbdcombination_str(fd,c);
                    *pspace=' ';
                    c=++pspace;
                }
                send_kbdcombination_str(fd,c);
                send_syn_event(fd);
            }
            free(code);
            if (ret == -1) break;
        }

        ioctl(fd, UI_DEV_DESTROY);
        if ( ! close(fd) ) warn(" uinput close");
    }
    else {
        /* we are using evdev */

        if ((fd = open(argv[optind], O_WRONLY)) < 0) 
        err(1," evdev open");

        while (lirc_nextcode(&code) == 0) {
            if (code == NULL) continue;
            while ((ret = lirc_code2char(config, code, &c)) == 0 &&
                  c != NULL) {
                char * pspace;
                
                if (debug) 
                    printf("%s -> ",code);
                while ( ( pspace=strchr(c,' ') ) ) {
                    *pspace='\0';
                    send_kbdcombination_str(fd,c);
                    *pspace=' ';
                    c=++pspace;
                }
                send_kbdcombination_str(fd,c);
                send_syn_event(fd);
            }
            free(code);
            if (ret == -1) break;
        }

        if ( ! close(fd) ) warn(" evdev close");
    }

    lirc_freeconfig(config);
    lirc_deinit();
    return ret;
}

void handlesign(int sign)
{
    if (debug)
        warnx(" caught signal %d, terminating.",sign);
     if ( typemodule == UINPUT_MODULE )
        ioctl(fd, UI_DEV_DESTROY);
    //close(fd);
    lirc_freeconfig(config);
    lirc_deinit();
    signal(sign,handlesign);
    exit(0);
}

