
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <asm/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>

#include <linux/input.h>

#define test_bit(bit, array)    (array[bit/8] & (1<<(bit%8)))

int main (int argc, char **argv) {

    int fd = -1;           /* the file descriptor for the device */
    char name[256]= "Unknown";
    uint8_t evtype_bitmask[EV_MAX/8 + 1];
    int yalv;
    struct input_id device_info;
    int version;


    /* read() requires a file descriptor, so we check for one, and then open it */
    if (argc != 2) {
fprintf(stderr, "usage: %s event-device - probably /dev/input/evdev0\n", argv[0]);
exit(1);
    }
    if ((fd = open(argv[1], O_RDONLY)) < 0) {
          perror("evdev open");
              exit(1);
                }

     /* ioctl() accesses the underlying driver */
     if (ioctl(fd, EVIOCGVERSION, &version)) {
              perror("evdev ioctl");
               }

      /* the EVIOCGVERSION ioctl() returns an int */
      /* so we unpack it and display it */
      printf("evdev driver version is %d.%d.%d\n",
                 version >> 16, (version >> 8) & 0xff, version & 0xff);

    /* suck out the name information 
     *    * return value is the length of the name, for success 
     *       * or -EFAULT for failure
     *          */
    if(ioctl(fd, EVIOCGNAME(sizeof(name)), name) < 0) {
              perror("evdev ioctl");
                }

    printf("The device on %s says it's name is %s\n", argv[1], name);

  /* suck out some device information */
      if(ioctl(fd, EVIOCGID, &device_info)) {
                perror("evdev ioctl");
                  }

        /* the EVIOCGID ioctl() returns input_devinfo
         *    * structure - see <linux/input.h> 
         *       * So we work through the various elements, displaying 
         *          * each of them 
         *             */
        printf("vendor 0x%04hx product 0x%04hx version 0x%04hx is on",
                     device_info.vendor, device_info.product, 
                         device_info.version);
                switch ( device_info.bustype)
                    {
                    case BUS_PCI :
                    printf(" a PCI bus\n");
                    break;
                    case BUS_ISAPNP :
                    printf(" a Plug-n-pray ISA bus\n");
                    break;
                    case BUS_USB :
                    printf(" a Universal Serial Bus\n");
                    break;
                    case BUS_ISA :
                    printf(" a legacy ISA bus\n");
                    break;
                    case BUS_I8042 :
                    printf(" an I8042 (or similar) controller\n");
                    break;
                    case BUS_XTKBD :
                    printf(" a IBM XT bus\n");
                    break;
                    case BUS_RS232 :
                    printf(" a RS232 serial bus\n");
                    break;
                    case BUS_GAMEPORT :
                    printf(" a gameport\n");
                    break;
                    case BUS_PARPORT :
                    printf(" a parallel port\n");
                    break;
                    case BUS_AMIGA :
                    printf(" an Amiga unique interface\n");
                    break;
                    case BUS_ADB :
                    printf(" an Apple Desktop Bus\n");
                    break;
                    case BUS_I2C :
                    printf(" a inter-integrated circuit bus\n");
                    break;
                    default:
                    printf(" an unknown bus type: 0x%04hx\n", device_info.bustype);
                    }

        memset(evtype_bitmask, 0, sizeof(evtype_bitmask));
if (ioctl(fd, EVIOCGBIT(0, EV_MAX), evtype_bitmask) < 0) {
          perror("evdev ioctl");
            }

  printf("Supported event types:\n");

    for (yalv = 0; yalv < EV_MAX; yalv++) {
        if (test_bit(yalv, evtype_bitmask)) {
            /* this means that the bit is set in the event types list */
            printf("  Event type 0x%02x ", yalv);
            switch ( yalv)
            {
                case EV_KEY :
                printf(" (Keys or Buttons)\n");
                break;
                case EV_REL :
                printf(" (Relative Axes)\n");
                break;
                case EV_ABS :
                printf(" (Absolute Axes)\n");
                break;
                case EV_MSC :
                printf(" (Something miscellaneous)\n");
                break;
                case EV_LED :
                printf(" (LEDs)\n");
                break;
                case EV_SND :
                printf(" (Sounds)\n");
                break;
                case EV_REP :
                printf(" (Repeat)\n");
                break;
                case EV_FF :
                printf(" (Force Feedback)\n");
                default:
                printf(" (Unknown event type: 0x%04hx)\n", yalv);
                }      
            }
        }

    close(fd);
    return(8);
}
